# Ingredients(for 4 people)

(1 Cup = 240ml)

* 1/2 cup rice

* 1/2 cup moong dal

* 1/2 cup jaggery

* 1 tea spoon elaichi powder

* 1/2 cup ghee

* 15 cashew piecies

* 1/4 cup dry coconut piecies

  